package it.uniroma3.diadia.giocatore;

import static org.junit.Assert.*;

import java.util.*;

import org.junit.Before;
import org.junit.Test;

import it.uniroma3.diadia.attrezzi.Attrezzo;

public class BorsaTest {
	public final static int DEFAULT_PESO_MAX_BORSA = 10;
	private Borsa b;
	private Attrezzo spada;
	private Attrezzo piombo;
	private Attrezzo piuma;
	private Attrezzo libro;
	private Attrezzo ps;



	@Before
	public void setUp() throws Exception {
		this.b= new Borsa(50);
		this.spada= new Attrezzo("spada", 4);
		this.piombo = new Attrezzo("piombo", 10);
		this.piuma = new Attrezzo("piuma", 1);
		this.libro = new Attrezzo("libro", 5);
		this.ps = new Attrezzo("ps", 5);
	}

	@Test
	public void testAddAttrezzo() {
		assertTrue(this.b.addAttrezzo(spada));
	}
	@Test
	public void testGetAttrezzoEsiste() {
		this.b.addAttrezzo(spada);
		assertEquals("spada", this.b.getAttrezzo("spada").getNome());
	}
	@Test
	public void testGetAttrezzoNonEsiste() {
		assertNull(this.b.getAttrezzo("martello"));
	}
	@Test
	public void testIsEmptyEsiste() {
		assertTrue(this.b.isEmpty());
	}
	@Test
	public void testIsEmptyNonEsiste() {
		this.b.addAttrezzo(spada);
		assertFalse(this.b.isEmpty());
	}
	@Test
	public void testRemoveEsiste() {
		this.b.addAttrezzo(spada);
		this.b.removeAttrezzo("spada");
		assertTrue(this.b.isEmpty());
	}
	@Test
	public void testRemoveNonEsiste() {
		this.b.addAttrezzo(spada);
		this.b.removeAttrezzo("martello");
		assertFalse(this.b.isEmpty());
	}

	@Test
	public void TestGetContenutoOrdinatoPerPeso() {

		this.b.addAttrezzo(piombo);
		this.b.addAttrezzo(ps);
		this.b.addAttrezzo(piuma);
		this.b.addAttrezzo(libro);


		Iterator<Attrezzo> iteratore= this.b.getContenutoOrdinatoPerPeso().iterator();
		assertTrue(iteratore.hasNext());
		assertEquals(piuma, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(libro, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(ps, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(piombo, iteratore.next());

	}
	
	@Test
	public void TestGetContenutoOrdinatoPerNome() {

		this.b.addAttrezzo(piombo);
		this.b.addAttrezzo(ps);
		this.b.addAttrezzo(piuma);
		this.b.addAttrezzo(libro);

        
		Iterator<Attrezzo> iteratore= this.b.getContenutoOrdinatoPerNome().iterator();
		assertTrue(iteratore.hasNext());
		assertEquals(libro, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(piombo, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(piuma, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(ps, iteratore.next());

	}
	
	@Test
	public void TestGetContenutoRaggruppatoPerPeso() {

		this.b.addAttrezzo(piombo);
		this.b.addAttrezzo(ps);
		this.b.addAttrezzo(piuma);
		this.b.addAttrezzo(libro);

        
		Map<Integer, Set<Attrezzo>> ordinata = this.b.getContenutoRaggruppatoPerPeso();
		
		Map<Integer, Set<Attrezzo>> risultatoAspettato= new HashMap<>();
		Set<Attrezzo> Peso1 = new HashSet<>();
		Peso1.add(piuma);
		risultatoAspettato.put(1, Peso1);
		Set<Attrezzo> Peso5 = new HashSet<>();
		Peso5.add(libro);
		Peso5.add(ps);
		risultatoAspettato.put(5, Peso5);
		Set<Attrezzo> Peso10 = new HashSet<>();
		Peso10.add(piombo);
		risultatoAspettato.put(10, Peso10);
		assertEquals(risultatoAspettato, ordinata);

	}
	
	@Test
	public void TestGetSortedSetOrdinatoPerPeso() {

		this.b.addAttrezzo(piombo);
		this.b.addAttrezzo(ps);
		this.b.addAttrezzo(piuma);
		this.b.addAttrezzo(libro);

        
		Iterator<Attrezzo> iteratore= this.b.getSortedSetOrdinatoPerPeso().iterator();
		assertTrue(iteratore.hasNext());
		assertEquals(libro, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(piombo, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(piuma, iteratore.next());
		assertTrue(iteratore.hasNext());
		assertEquals(ps, iteratore.next());

	}

}
