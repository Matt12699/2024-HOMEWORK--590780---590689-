package it.uniroma3.diadia.ambienti;
import it.uniroma3.diadia.IO;
import it.uniroma3.diadia.attrezzi.*;
import java.util.*;

public class LabirintoBuilder { 
	
	public Labirinto labirinto;
	public Stanza ultimaStanzaAggiunta;
	public Map<String, Stanza> nome2stanza;
	
	public LabirintoBuilder() {
		this.labirinto= new Labirinto();
		this.nome2stanza= new HashMap<>();
	}
	
	public Map<String, Stanza> getNome2stanza() {
		return nome2stanza;
	}
	
	public LabirintoBuilder addStanzaIniziale(String nomeStanzaIniziale) {
		
		Stanza stanzaIniziale = new Stanza(nomeStanzaIniziale);
		this.labirinto.setStanzaIniziale(stanzaIniziale);
		this.aggiornaUltimaStanzaAggiunta(stanzaIniziale);
		return this;
	}
	
	public LabirintoBuilder addStanzaVincente(String nomeStanzaVincente) {
		
		Stanza stanzaVincente = new Stanza(nomeStanzaVincente);
		this.labirinto.setStanzaVincente(stanzaVincente);
		this.aggiornaUltimaStanzaAggiunta(stanzaVincente);
		return this;
	}
	
	public Labirinto getLabirinto() {
		return this.labirinto;
	}
	
	public LabirintoBuilder addAttrezzo(String nomeAttrezzo, int peso) {
		Attrezzo attrezzo = new Attrezzo(nomeAttrezzo, peso);
		if(this.ultimaStanzaAggiunta==null || this.ultimaStanzaAggiunta.getAttrezzo(nomeAttrezzo)!=null) 
			return this;
		this.ultimaStanzaAggiunta.addAttrezzo(attrezzo);
		return this;
	}
	
	public LabirintoBuilder addAdiacenza(String nomeStanza, String nomeStanzaAdiacente, String direzione) {
		if(this.nome2stanza.get(nomeStanza).getDirezioni().size()==4)
			return this;
		Stanza corrente= this.nome2stanza.get(nomeStanza);
		Stanza adiacente=this.nome2stanza.get(nomeStanzaAdiacente);
		
		corrente.impostaStanzaAdiacente(direzione, adiacente);
		
		return this;
	}
	
	public LabirintoBuilder addStanza(String nome) {
		Stanza stanza = new Stanza(nome);
		this.aggiornaUltimaStanzaAggiunta(stanza);
		return this;
	}
	
	public LabirintoBuilder addStanzaMagica(String nome, int sogliaMagica) {
		Stanza stanza = new StanzaMagica(nome, sogliaMagica);
		this.aggiornaUltimaStanzaAggiunta(stanza);
		return this;
	}
	
	public LabirintoBuilder addStanzaBuia(String nome) {
		Stanza stanza = new StanzaBuia(nome);
		this.aggiornaUltimaStanzaAggiunta(stanza);
		return this;
	}
	
	public LabirintoBuilder addStanzaBloccata(String nome, String direzioneBloccata, String attrezzoSbloccatore) {
		Stanza stanza = new StanzaBloccata(nome, direzioneBloccata, attrezzoSbloccatore);
		this.aggiornaUltimaStanzaAggiunta(stanza);
		return this;
	}
	
	public void aggiornaUltimaStanzaAggiunta(Stanza stanza) {
		this.ultimaStanzaAggiunta= stanza;
		this.nome2stanza.put(stanza.getNome(), stanza);
	}

}
