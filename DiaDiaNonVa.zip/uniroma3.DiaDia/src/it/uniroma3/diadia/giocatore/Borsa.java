package it.uniroma3.diadia.giocatore;

import it.uniroma3.diadia.attrezzi.Attrezzo;



import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;

public class Borsa {

	public final static int DEFAULT_PESO_MAX_BORSA = 10;

	private List<Attrezzo> attrezzi;
	private int pesoMax;
	public Borsa() {
		this(DEFAULT_PESO_MAX_BORSA);
		this.attrezzi= new ArrayList<Attrezzo>();
	}
	public Borsa(int pesoMax) {
		this.pesoMax = pesoMax;
		this.attrezzi= new ArrayList<Attrezzo>();
	}
	public boolean addAttrezzo(Attrezzo attrezzo) {

		if (this.getPeso() + attrezzo.getPeso() > this.getPesoMax())
			return false;
		return this.attrezzi.add(attrezzo);
	}
	public int getPesoMax() {
		return pesoMax;
	}
	public Attrezzo getAttrezzo(String nomeAttrezzo) {
		Attrezzo a = null;
		Iterator<Attrezzo> iteratore= this.attrezzi.iterator();
		while (iteratore.hasNext()) {
			Attrezzo att= iteratore.next();
			if(att.getNome().equals(nomeAttrezzo))
				a=att;		
		}
		return a;
	}

	public int getPeso() {
		int pesoTotale = 0;
		Iterator<Attrezzo> iteratore= this.attrezzi.iterator();
		while (iteratore.hasNext()) {
			Attrezzo a = iteratore.next();
			pesoTotale += a.getPeso();
		}
		return pesoTotale;
	}

	public boolean isEmpty() {
		return this.attrezzi.size() == 0;
	}

	public boolean hasAttrezzo(String nomeAttrezzo) {
		return this.getAttrezzo(nomeAttrezzo)!=null;
	}

	public Attrezzo removeAttrezzo(String nomeAttrezzo) {
		Attrezzo a = null;
		Iterator<Attrezzo> iteratore= this.attrezzi.iterator();
		while(iteratore.hasNext()) {
			Attrezzo att= iteratore.next();
			if(nomeAttrezzo.equals(att.getNome())) {
				iteratore.remove();
				return att;
			}
		}
		return null;
	}
	public String toString() {
		StringBuilder s = new StringBuilder();
		Iterator<Attrezzo> iteratore= this.getContenutoOrdinatoPerPeso().iterator();

		if (!this.isEmpty()) {
			s.append("Contenuto borsa ("+this.getPeso()+"kg/"+this.getPesoMax()+"kg): ");
			while(iteratore.hasNext()) {
				Attrezzo att= iteratore.next();
				s.append(att.toString()+" ");
			}
		}
		else
			s.append("Borsa vuota");
		return s.toString();
	}

	public boolean searchAtt(String nomeAttrezzo) {
		Iterator<Attrezzo> iteratore=this.attrezzi.iterator();
		while(iteratore.hasNext()) {
			Attrezzo att=iteratore.next();
			if(nomeAttrezzo.equals(att.getNome()))
				return true;
		}
		return false;
	}
	
	
	//restituisce la lista degli attrezzi nella borsa ordinati per peso e
	//quindi, a parit� di peso, per nome
	public List<Attrezzo> getContenutoOrdinatoPerPeso(){
		List<Attrezzo> ordinata= new ArrayList<>(this.attrezzi);
	    ComparatorePerPeso cmp= new ComparatorePerPeso();
		
		
		Collections.sort(ordinata, cmp);
		
		return ordinata;
	}
	
	//restituisce l'insieme degli attrezzi nella borsa ordinati per nome
	public SortedSet<Attrezzo> getContenutoOrdinatoPerNome(){
		final SortedSet<Attrezzo> ordinata= new TreeSet<>(this.attrezzi);
		
		return ordinata;
	}
	
	//restituisce una mappa che associa un intero (rappresentante un
	//peso) con l�insieme (comunque non vuoto) degli attrezzi di tale
	//peso: tutti gli attrezzi dell'insieme che figura come valore hanno
	//lo stesso peso pari all'intero che figura come chiave
	public Map<Integer,Set<Attrezzo>> getContenutoRaggruppatoPerPeso(){
		final Map<Integer, Set<Attrezzo>> peso2attrezzi = new HashMap<>();
		
		for(Attrezzo att : this.attrezzi) {
			if(peso2attrezzi.containsKey(att.getPeso())) {
				// questo attrezzo ha un peso che ho gia visto in precedenza
				// pesco il vecchio set con lo stesso peso e aggiungo il nuovo arrivato
				final Set<Attrezzo> stessoPeso = peso2attrezzi.get(att.getPeso());
				stessoPeso.add(att);
			}else {
				final Set<Attrezzo> nuovoPeso = new HashSet<>();
				nuovoPeso.add(att);
				peso2attrezzi.put(att.getPeso(), nuovoPeso);
			}
		}
		
		return peso2attrezzi;
	}
	
	//restituisce l'insieme gli attrezzi nella borsa
	//ordinati per peso e quindi, a parit� di peso, per
	//nome
	public SortedSet<Attrezzo> getSortedSetOrdinatoPerPeso(){
		
		final SortedSet<Attrezzo> ordinata = new TreeSet<>(this.getContenutoOrdinatoPerPeso());
		
		return ordinata;
		
	}
}